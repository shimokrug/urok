import { test } from 'node:test';
import assert from 'node:assert/strict';
import { lessons, professions, trainerExample } from '../dist/course.js';
import { createState, restoreState, progress, isUnlocked, resumeIndex, analysePrompt, evaluate, recordAttempt } from '../dist/engine.js';

const answers={
  3:trainerExample,
  4:'Подготовь план встречи для команды из 3 человек на 5 рабочих дней. Формат: таблица день / задача / ответственный. Предложи два варианта. Если данных не хватает, задай вопросы.',
  5:'Тема: Перенос встречи\nКоллеги, добрый день! Встреча в среду переносится с 14:00 на 16:00. Кабинет 204 остаётся прежним. Пожалуйста, подтвердите участие.',
  6:'Всего 310 заявок, среднее 103,3. Максимум — февраль, 120 заявок. В марте снижение на 25%. Причина неизвестна: данных недостаточно.',
  8:'Коллеги, приглашаю на встречу по проекту «Маяк» в среду в 15:00 на 30 минут. Повестка: согласование задач и ответственных.',
  9:'Вход: {период}, {данные}. 1. Собери сведения. 2. Составь отчёт. 3. Сверь числа. Формат: таблица и список выводов. Руководитель проверяет отчёт перед отправкой. Если данных не хватает, запроси уточнение.',
  10:'Анализ: неделя 1 — 120, неделя 2 — 150, рост 25%. Причина неизвестна. Тема: Динамика заявок. Руководителю: предлагаю запросить данные по каналам. Проверка: пересчёт и сверка исходных чисел. Письмо согласовать перед отправкой.'
};
test('10 последовательных чекпоинтов проходят только с ответами; после сохранения 100%',()=>{
  const s=createState();assert.equal(isUnlocked(s,1),false);
  for(let i=0;i<lessons.length;i++){
    assert.equal(isUnlocked(s,i),true);
    assert.equal(evaluate(lessons[i],s.entries[i],professions[0]).passed,false);
    s.current=i;s.entries[i].visited=true;
    if(lessons[i].type==='quiz')lessons[i].questions.forEach((q,j)=>s.entries[i].choices[j]=q.correct);
    else s.entries[i].answer=answers[i+1];
    const r=recordAttempt(s,i);assert.equal(r.passed,true,`${i+1}: ${JSON.stringify(r.criteria.filter(c=>!c.passed))}`);
  }
  assert.deepEqual(progress(restoreState(JSON.parse(JSON.stringify(s)))) ,{done:10,total:10,percent:100});
});
test('этап 1 требует 4/5, этапы безопасности и проверки требуют 5/5; незаполненные ответы не проходят',()=>{
  for(const index of [0,1,6]){
    const s=createState();lessons[index].questions.forEach((q,j)=>s.entries[index].choices[j]=q.correct);
    s.entries[index].choices[0]=!lessons[index].questions[0].correct;
    assert.equal(evaluate(lessons[index],s.entries[index],professions[0]).passed,index===0);
    delete s.entries[index].choices[0];assert.equal(evaluate(lessons[index],s.entries[index],professions[0]).passed,false);
  }
});
test('тренажёр оценивает компоненты, а не длину',()=>{
  assert.equal(analysePrompt('Напиши отчёт').filter(c=>c.passed).length,1);
  assert.equal(analysePrompt('Очень хороший текст. '.repeat(200)).filter(c=>c.passed).length,0);
  assert.equal(analysePrompt(trainerExample).filter(c=>c.passed).length,6);
});
test('восстанавливаются черновик, специализация, попытки и текущая часть урока',()=>{
  const s=createState();s.profession='hr';s.started=true;s.current=2;s.section='practice';s.entries[2].answer='Незавершённый запрос <тест>';s.entries[2].visited=true;s.entries[2].attempts=2;
  const restored=restoreState(JSON.parse(JSON.stringify(s)));
  assert.equal(restored.entries[2].answer,s.entries[2].answer);assert.equal(restored.profession,'hr');assert.equal(restored.section,'practice');assert.equal(resumeIndex(restored),2);assert.equal(progress(restored).percent,0);
  assert.equal(restoreState({version:99}).current,0);
});
test('каждая специализация имеет работающее проверяемое упражнение',()=>{
  const examples={office:answers[8],manager:'Этапы проекта на две недели. Ответственный: координатор. Контрольная точка в конце недели. Риск задержки согласования — заранее запросить проверку.',analyst:'Всего 310 заявок. В марте снижение на 25 %. Причина неизвестна, нужно запросить дополнительные данные.',it:'В 10:00 сервис недоступен, в 10:20 восстановлен. Причина неизвестна. Проверить журналы. Рекомендации: мониторинг.',hr:'Обязанности: координировать задачи. Навыки: планирование. Вопросы: Как вы ведёте план? Как разрешаете конфликт сроков? Как отслеживаете задачи? Условия уточнить.',other:'Входные данные: статусы задач. Шаги: собрать сведения, сделать сводку в таблице. Руководитель проверяет результат.'};
  for(const p of professions){const e=createState().entries[7];e.answer=examples[p.id];const r=evaluate(lessons[7],e,p);assert.equal(r.passed,true,`${p.id}: ${JSON.stringify(r.criteria.filter(c=>!c.passed))}`);}
});
test('неудачная повторная попытка не удаляет уже освоенный навык',()=>{
  const s=createState();s.entries[2].answer=trainerExample;recordAttempt(s,2);s.entries[2].answer='Письмо';recordAttempt(s,2);assert.equal(s.entries[2].status,'completed');assert.equal(s.entries[2].result.passed,false);assert.equal(s.entries[2].attempts,2);
});
test('важные факты обязательны: одного упоминания формата недостаточно',()=>{
  const s=createState();s.entries[2].answer=trainerExample.replace('15:00','17:00');assert.equal(evaluate(lessons[2],s.entries[2],professions[0]).passed,false);
  s.entries[4].answer=answers[5]+' Причина — 300 участников.';assert.equal(evaluate(lessons[4],s.entries[4],professions[0]).passed,false);
});
